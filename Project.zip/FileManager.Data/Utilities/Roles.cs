﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManager.Data.Utilities
{
    public class Roles
    {
        public static readonly string ADMINROLE = "Administrator";
        public static readonly string USERROLE = "User";
    }
}
